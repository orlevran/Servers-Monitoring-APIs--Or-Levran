package com.example.servers_monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServersMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServersMonitoringApplication.class, args);
	}

}
